import json
from playwright.sync_api import sync_playwright
CSS=open('og.html').read().split('<style>')[1].split('</style>')[0]
CSS+="""
.left{justify-content:flex-start}
h1,h1 em,p.sub{text-wrap:balance}
.sheet{overflow:hidden}
.back.plain .cut:after{display:none}
.third{left:204px;top:36px;width:280px;height:380px;transform:rotate(14deg);opacity:.75;padding:0}
.summ{background:#ECFDF5;border-left:3px solid #34D399;border-radius:4px;padding:10px 10px 2px;margin-bottom:6px}
.summ .l{background:rgba(52,211,153,.45)}
.chip.on{background:#34D399;border-color:#34D399}
.chip.dk{background:#065F46;border-color:#065F46}
.verb{height:8px;width:48px;border-radius:4px;background:#065F46;flex:none}
.num{height:14px;width:34px;border-radius:7px;background:#34D399;flex:none}
.date{height:6px;width:40px;border-radius:3px;background:#C9C0B3;flex:none}
.gapbox{border:1.5px dashed #34D399;border-radius:6px;padding:8px 10px;margin:10px 0;display:flex;gap:10px;align-items:center;background:#F0FDF7}
.gapbox .l{margin:0;flex:1}
.para .l{margin-bottom:8px}
.para{margin-bottom:14px}
.scanline{position:absolute;left:-10px;right:-10px;top:210px;height:3px;background:#34D399;box-shadow:0 0 18px 6px rgba(52,211,153,.45)}
.scanfade{position:absolute;left:0;right:0;top:0;height:212px;background:linear-gradient(180deg,rgba(236,253,245,0),rgba(236,253,245,.7))}
.corner{position:absolute;width:18px;height:18px;border-color:#065F46;border-style:solid}
"""
def rows(pat):
    out=""
    for w,hl in pat:
        out+=f'<div class="row"><div class="dot"></div><div class="l{" hl" if hl else ""}" style="max-width:{w}%"></div></div>'
    return out
HEAD='<div class="name"></div><div class="role"></div>'
def chips(ws,cls=""):
    return '<div class="chips">'+"".join(f'<div class="chip {c}" style="width:{w}px"></div>' for w,c in ws)+'</div>'
def front(kind):
    if kind=="default":
        return HEAD+'<div class="h"></div>'+rows([(88,1),(76,0),(82,1)])+'<div class="h"></div>'+rows([(90,0),(70,1)])+'<div class="h"></div>'+rows([(80,0)])+'<div class="h" style="width:26%"></div>'+chips([(58,""),(44,""),(66,""),(40,"")])
    if kind=="summary":
        return HEAD+'<div class="summ"><div class="l" style="width:96%"></div><div class="l" style="width:88%"></div><div class="l" style="width:70%"></div></div><div class="h"></div>'+rows([(86,0),(74,0),(80,0)])+'<div class="h"></div>'+rows([(88,0),(66,0)])+'<div class="h" style="width:26%"></div>'+chips([(58,""),(44,""),(66,"")])
    if kind=="skills":
        return HEAD+'<div class="h"></div>'+rows([(86,0),(72,0)])+'<div class="h"></div>'+rows([(80,0)])+'<div class="h" style="width:30%;margin-top:20px"></div>'+chips([(62,"dk"),(48,"on"),(70,"on"),(40,"")])+'<div style="height:8px"></div>'+chips([(52,"on"),(76,""),(44,"on"),(54,"dk")])+'<div style="height:8px"></div>'+chips([(66,""),(50,"on"),(60,"on")])
    if kind=="verbs":
        def vr(w,hl=0): return f'<div class="row"><div class="dot"></div><div class="verb"></div><div class="l{" hl" if hl else ""}" style="max-width:{w}%"></div></div>'
        return HEAD+'<div class="h"></div>'+vr(70,1)+vr(62)+vr(74,1)+'<div class="h"></div>'+vr(66)+vr(58,1)+vr(70)+'<div class="h"></div>'+vr(64,1)+vr(54)
    if kind=="metrics":
        def mr(w): return f'<div class="row"><div class="dot"></div><div class="l" style="max-width:{w}%"></div><div class="num"></div></div>'
        return HEAD+'<div class="h"></div>'+mr(70)+mr(62)+mr(74)+'<div class="h"></div>'+mr(66)+mr(58)+'<div class="h"></div>'+mr(72)+'<div class="h" style="width:26%"></div>'+chips([(58,""),(44,""),(66,"")])
    if kind=="gap":
        def tr(w): return f'<div class="row"><div class="date"></div><div class="l" style="max-width:{w}%"></div></div>'
        return HEAD+'<div class="h"></div>'+tr(80)+rows([(74,0),(66,0)])+'<div class="gapbox"><div class="date" style="background:#34D399"></div><div class="l hl"></div></div>'+tr(76)+rows([(70,0),(78,0)])+'<div class="h"></div>'+rows([(72,0)])
    if kind=="letter":
        def p(ws,hl=False): return '<div class="para">'+"".join(f'<div class="l{" hl" if hl else ""}" style="width:{w}%"></div>' for w in ws)+'</div>'
        sig='<svg width="90" height="28" viewBox="0 0 90 28"><path d="M4 20c8-14 14-14 12-4s6-12 12-6-2 12 6 8 10-10 14-6 4 8 12 2 10-4 16-2" fill="none" stroke="#065F46" stroke-width="2.4" stroke-linecap="round"/></svg>'
        return '<div class="name" style="width:44%;height:12px"></div><div class="l" style="width:30%;margin:8px 0 22px"></div><div class="l" style="width:26%;background:#0C1A0E;opacity:.7;margin-bottom:16px"></div>'+p([96,90,94,60])+p([94,88,92,70],True)+p([90,84,50])+'<div class="l" style="width:22%"></div>'+sig
def back(kind):
    cls="sheet back"+("" if kind=="cut" else " plain")
    inner='''<div class="l" style="width:55%;height:12px;background:#E0D8CC"></div><div class="l" style="width:35%;margin-bottom:24px"></div>
<div class="l cut" style="width:92%"></div><div class="l cut" style="width:80%"></div><div class="l cut" style="width:86%"></div>
<div class="l" style="width:30%;margin-top:22px;background:#E0D8CC"></div>
<div class="l cut" style="width:88%"></div><div class="l cut" style="width:74%"></div><div class="l cut" style="width:90%"></div><div class="l cut" style="width:66%"></div>
<div class="l" style="width:30%;margin-top:22px;background:#E0D8CC"></div><div class="l cut" style="width:84%"></div><div class="l cut" style="width:70%"></div>'''
    extra='<div class="sheet third"></div>' if kind=="stack" else ""
    return extra+f'<div class="{cls}">{inner}</div>'
IC={
"briefcase":'<rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
"sparkles":'<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 17v4M17 19h4"/>',
"zap":'<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/>',
"cap":'<path d="M22 10 12 5 2 10l10 5 10-5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/>',
"mail":'<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
"calendar":'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
"book":'<path d="M2 4h6a4 4 0 0 1 4 4v13a3 3 0 0 0-3-3H2z"/><path d="M22 4h-6a4 4 0 0 0-4 4v13a3 3 0 0 1 3-3h7z"/>',
"users":'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
"cloud":'<path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9z"/>',
"calc":'<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 11h.01M12 11h.01M16 11h.01M8 15h.01M12 15h.01M16 15h.01M8 19h.01M12 19h.01M16 19h.01"/>',
"trend":'<path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M16 7h6v6"/>',
"pulse":'<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7z"/><path d="M3.22 12H9.5l.5-1 2 4.5 2-7 1.5 3.5h5.27"/>',
"crown":'<path d="m2 4 3 12h14l3-12-6 7-4-7-4 7-6-7z"/><path d="M5 20h14"/>',
"globe":'<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20"/>',
"scan":'<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2M7 12h10"/>',
"landmark":'<path d="M3 22h18M6 18v-7M10 18v-7M14 18v-7M18 18v-7M12 2l8 5H4z"/>',
"swap":'<path d="m16 3 4 4-4 4M20 7H4M8 21l-4-4 4-4M4 17h16"/>',
"sprout":'<path d="M7 20h10M12 20v-8M12 12c0-4-3-6-7-6 0 4 3 6 7 6zM12 12c0-4 3-7 7-7 0 4-3 7-7 7z"/>',
"quote":'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 9h8M8 13h5"/>',
"scissors":'<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4 8.1 15.9M14.5 14.5 20 20M8.1 8.1 12 12"/>',
}
LOGO='<svg width="44" height="44" viewBox="0 0 38 38" fill="none"><rect width="38" height="38" rx="7" fill="#065F46"/><g stroke-linecap="round" stroke-width="2.2"><path d="M8.5 10.5H26" stroke="#FFFFFF"/><path d="M8.5 16.5H21.5" stroke="#FFFFFF" stroke-opacity=".6"/><path d="M8.5 22.5H23.5" stroke="#FFFFFF" stroke-opacity=".6"/><path d="M8.5 28.5H17.5" stroke="#FFFFFF" stroke-opacity=".6"/></g><circle cx="32" cy="9" r="3.6" fill="#065F46" stroke="#34D399" stroke-width="2.2"/></svg>'
P=json.load(open('posts.json'))
def page(p):
    big=p["badge"][0]; fs={1:44,2:40,3:32,4:26}.get(len(big),24)
    scan='<div class="scanfade"></div><div class="scanline"></div>' if p.get("scan") else ""
    return f'''<!DOCTYPE html><html><head><meta charset="utf-8"><style>{CSS}</style></head><body>
<div class="grid"></div><div class="glow"></div>
<div class="left" id="left"><div class="pill"><i></i>{p["pill"]}</div>
<h1 id="h">{p["t1"]}<em>{p["t2"]}</em></h1><p class="sub">{p["sub"]}</p>
<div class="brand">{LOGO}<div class="word">CV<span>Edge</span></div><div class="sep"></div><div class="url">thecvedge.com</div></div></div>
<div class="stage">{back(p.get("back","plain"))}<div class="sheet front">{front(p["front"])}{scan}</div>
<div class="scissor"><svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#065F46" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{IC[p["icon"]]}</svg></div>
<div class="badge"><b style="font-size:{fs}px">{big}</b><s>{p["badge"][1]}</s></div></div>
<script>
const h=document.getElementById('h'),L=document.getElementById('left');let f=54;
function over(){{const lh=parseFloat(getComputedStyle(h).lineHeight);return L.scrollHeight>L.clientHeight+1||h.offsetHeight>lh*4.3}}
while(over()&&f>36){{f-=1;h.style.fontSize=f+'px'}}
</script></body></html>'''
with sync_playwright() as pw:
    b=pw.chromium.launch(); pg=b.new_page(viewport={'width':1200,'height':630})
    for p in P:
        open('tmp.html','w').write(page(p)); pg.goto('file:///home/claude/og/tmp.html'); pg.wait_for_timeout(300)
        pg.screenshot(path=f'/home/claude/og/out/{p["slug"]}.png')
    b.close()
